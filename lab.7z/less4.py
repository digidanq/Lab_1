name = input("What's your name?\n> ")
print(f"Hi {name}, welcome to class))")