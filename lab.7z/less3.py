name = "Danila"
major = "Informatics"
university = "University of Information Technology and Management in Rzeszów"

print("My name is " + name + " and I study " + major + " at the " + university + ".")